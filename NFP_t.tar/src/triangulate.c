#include "bibliotecas.h"

void triangulate(_polygon *p, _triangulation *t) {
    int l[MAXPOLY], r[MAXPOLY];    // left/right neighbor indices
    int i;                

    for (i=0; i<p->n; i++) {    // initialization
        l[i] = ((i-1) + p->n) % p->n;
        r[i] = ((i+1) + p->n) % p->n;
    }

    t->n = 0;
    i = p->n-1;
    while (t->n < (p->n-2)) {
        i = r[i];
        if (ear_Q(l[i],i,r[i],p)) {
            add_triangle(t,l[i],i,r[i],p);
            l[ r[i] ] = l[i];
            r[ l[i] ] = r[i];
        }
    }
}

bool point_in_triangle(_point p, triangle t){
    int i;                  

    for (i=0; i<3; i++)
        if (cw(t[i],t[(i+1)%3],p)) return(FALSE);

    return(TRUE);
}

void add_triangle(_triangulation *t, int i, int j, int k, _polygon *p){
    int n;                  // number of triangles in t

    n = t->n;

    t->t[n][0] = i;
    t->t[n][1] = j;
    t->t[n][2] = k;

    t->n = n + 1;
}

bool ear_Q(int i, int j, int k, _polygon *p){
    triangle t;             // coordinates for points i,j,k
    int m;

    copy_point(p->p[i],t[0]);
    copy_point(p->p[j],t[1]);
    copy_point(p->p[k],t[2]);

    if (cw(t[0],t[1],t[2])) return(FALSE);

    for (m=0; m<p->n; m++) {
        if ((m!=i) && (m!=j) && (m!=k))
            if (point_in_triangle(p->p[m],t)) return(FALSE);
    }

    return(TRUE);
}
