#include "bibliotecas.h"

// data read from the general data of instance
// description: This function reads the number item types, the demand, the amount of rotation of each item and its rotations as well as their IDs. Furthermore reads the number of bins and their IPs.
int general_data(char *filename, int *n, _item **items){

    int i,j;

    FILE *arq;
    char local[50];
    char comment[100];

    _item *itemlist;
    itemlist = *items;

    sprintf(local,"instances/%s/general_data.in", filename);

    //open file for reading data ("r" = read)
    arq = fopen(local, "r"); 

    //check if you can open the data file
    if (arq == NULL){
        printf("\n\nError opening file!aki\n\n");
        return(-1);
    }

    //reads the comment
    fscanf(arq, "%[^\n]s", comment);

    //reads the first line of the file -> number of different types of items (n)
    fscanf(arq, "\n%d", n); 

    //allocate a vector for storing n pointers to items
    itemlist = (_item *) calloc(*n, sizeof(_item));
    if (itemlist == NULL) {
        printf("\n\nMemory allocation error!\n\n");
        return(-1);
    }

    //reading the items 
    for (i = 0; i < *n; i++) {

        //reads the comment 
        fscanf(arq, "\n%[^\n]s", comment);

        //reads the ID, demand, flip, number rotations 
        fscanf(arq, "%d %d %d", &(itemlist[i].ID), &(itemlist[i].flip), &(itemlist[i].nr)); 

        //allocates an array with the rotation 
        itemlist[i].rotations = (double *) calloc(itemlist[i].nr, sizeof(double));

        if (itemlist[i].rotations == NULL) {
            printf("\n\nMemory allocation error!2\n\n");
            return(-1);
        }


        //reads the rotations 
        for (j = 0; j < itemlist[i].nr; j++)
            fscanf(arq, "%lf", &(itemlist[i].rotations[j])); 

    }

    *items = itemlist;

    //closes the input file after finishing reading the data 
    fclose(arq);

    return(0);


}

// data read from the items data
// description: This function reads the items from the input files. The input parameter is the filename of instance and  the number of items (n) and the items (_item). And output parameters is a vector with the characteristics of each item (flip of item, number of solid polygons and hole polygons, and number of vertices of each polygon and the vertices).
int items_data(char *filename, int *n, _item **items){

    int i,j,k;

    FILE *arq;
    char local[50];
    char comment[100];

    _item *itemlist;
    itemlist = *items;

    //reading the items polygons
    for (i = 0; i < *n; i++) {

        sprintf(local,"instances/%s/items/item_%d.in", filename, itemlist[i].ID);

        //  open file for reading data ("r" = read)
        arq = fopen(local, "r"); 

        if (arq == NULL) {
            printf("File %s not found.\n", local);
            return(-1);
        }

        //reads the comment 
        fscanf(arq, "%[^\n]s", comment);

        //reads the number of simple polygons
        fscanf(arq, "%d", &(itemlist[i].np)); 


        //allocate the array of polygons partials 
        itemlist[i].polygon = (_polygon *) calloc(itemlist[i].np, sizeof(_polygon));

        if (itemlist[i].polygon == NULL) {
            printf("\n\nMemory allocation error!\n\n");
            return(-1);
        }


        for (j = 0; j < itemlist[i].np; j++) {

            //reads the comment
            fscanf(arq, "\n%[^\n]s", comment);
            fscanf(arq, "\n%[^\n]s", comment);

            //reads the amount of vertices of polygon j
            fscanf(arq, "%d", &(itemlist[i].polygon[j].n));

            //reads the comment
            fscanf(arq, "\n%[^\n]s", comment);

            for (k = 0; k < itemlist[i].polygon[j].n; k++) {

                //      reads the point (x, y) for each node k to the polygon k of bin i
                fscanf(arq, "%lf %lf", &(itemlist[i].polygon[j].p[k][X]), &(itemlist[i].polygon[j].p[k][Y])); 
            }  
        }
        fclose(arq);
    }
    *items = itemlist;
    return(0);
}
