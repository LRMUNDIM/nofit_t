#include "bibliotecas.h"

void new_polygon(_polygon *p, _polygon *new_p, double rotation, int flip) {

    int i;
    double theta, x, y;

    theta = DEGREES_RADIANS(rotation);
    new_p->n = p->n;
    for(i=0; i<new_p->n; i++){
        x = (1-2*flip)*p->p[i][X]; 
        y = p->p[i][Y];

        new_p->p[i][X] = rotationX(x,y,theta);
        new_p->p[i][Y] = rotationY(x,y,theta);
    }

    return;
}

bool point_in_polygon_convex_grid(_point point, _polygon p){
    int i;                  

    for (i=0; i<p.n; i++){
        if (d_func(p.p[i],p.p[(i+1)%p.n],point)<=0){
            return(FALSE);
        }
    }
    return(TRUE);
}

void nfp(_polygon *pa, _triangulation *ta, _polygon *pb, _triangulation *tb, _nofit *nfp){
    int i, j, k, l;
    double x, y;
    int cont, idx;
    int order[6];
    _point ra, rb;          // point of reference of a and b
    double angles[6];
    double angleMin;

    (*nfp).n = ta->n * tb->n;//number of parts

    //calculate the nfp of part ij
    cont = 0;
    for (i=0; i< ta->n; i++) {
        for (j=0; j< tb->n; j++) {

            (*nfp).nfp[cont].n = 6;

            //reference point polygon fix
            copy_point(pa->p[ta->t[i][0]], ra);

            if ((ra[Y] > (pa->p[ta->t[i][1]][Y])) || ((fabs(ra[Y] - (pa->p[ta->t[i][1]][Y])) < ZERO) && (ra[X] > (pa->p[ta->t[i][1]][X]))))
                copy_point(pa->p[ta->t[i][1]], ra);
            if ((ra[Y] > (pa->p[ta->t[i][2]][Y])) || ((fabs(ra[Y] - (pa->p[ta->t[i][2]][Y])) < ZERO) && (ra[X] > (pa->p[ta->t[i][2]][X]))))
                copy_point(pa->p[ta->t[i][2]], ra);

            //reference point polygon orbital
            copy_point(pb->p[tb->t[j][0]], rb);

            if ((rb[Y] < (pb->p[tb->t[j][1]][Y])) || ((fabs(rb[Y] - (pb->p[tb->t[j][1]][Y])) < ZERO) && (rb[X] < (pb->p[tb->t[j][1]][X]))))
                copy_point(pb->p[tb->t[j][1]], rb);
            if ((rb[Y] < (pb->p[tb->t[j][2]][Y])) || ((fabs(rb[Y] - (pb->p[tb->t[j][2]][Y])) < ZERO) && (rb[X] < (pb->p[tb->t[j][2]][X]))))
                copy_point(pb->p[tb->t[j][2]], rb);

            //concatenando the segments
            for ( k = 0; k < 3; k++){
                (*nfp).nfp[cont].p[k][X] = (pa->p[ta->t[i][(k+1)%3]][X] - pa->p[ta->t[i][k]][X]);
                (*nfp).nfp[cont].p[k][Y] = (pa->p[ta->t[i][(k+1)%3]][Y] - pa->p[ta->t[i][k]][Y]);
            }
            for ( k = 0; k < 3; k++){
                (*nfp).nfp[cont].p[k+3][X] = -(pb->p[(tb->t[j][(k+1)%3])][X] - pb->p[(tb->t[j][k])][X]);
                (*nfp).nfp[cont].p[k+3][Y] = -(pb->p[(tb->t[j][(k+1)%3])][Y] - pb->p[(tb->t[j][k])][Y]);
            }

            //calculate the angle
            for ( k = 0; k < 6; k++){
                angles[k] = angle((*nfp).nfp[cont].p[k]);
                order[k] = k;
            }

            //order the segments
            idx = 0;
            for ( k = 1; k < 6; k++){
                idx = k;
                while ( idx > 0 && angles[idx] < angles[idx-1]) {
                    angleMin = angles[idx];
                    angles[idx] = angles[idx-1];
                    angles[idx-1] = angleMin;

                    l = order[idx];
                    order[idx] = order[idx-1];
                    order[idx-1] = l;

                    idx--;
                }
            }

            //reordering the vertices of nofit polygon
            for ( k = 0; k < 6; k++){
                x = (*nfp).nfp[cont].p[k][X];
                y = (*nfp).nfp[cont].p[k][Y];

                (*nfp).nfp[cont].p[k][X] = (*nfp).nfp[cont].p[order[k]][X];
                (*nfp).nfp[cont].p[k][Y] = (*nfp).nfp[cont].p[order[k]][Y];

                (*nfp).nfp[cont].p[order[k]][X] = x;
                (*nfp).nfp[cont].p[order[k]][Y] = y;

                idx = order[k];                
                l = k;
                while (k != order[l]) l++;

                order[k] = k;
                order[l] = idx;

            }

            //concatenate edges
            x = (*nfp).nfp[cont].p[0][X];
            y = (*nfp).nfp[cont].p[0][Y];

            k = 0;
            (*nfp).nfp[cont].p[k][X] += (ra[X] - 1*rb[X]);
            (*nfp).nfp[cont].p[k][Y] += (ra[Y] - 1*rb[Y]);

            for (k = 1; k < 6; k++) {
                (*nfp).nfp[cont].p[k][X] += (*nfp).nfp[cont].p[k-1][X];
                (*nfp).nfp[cont].p[k][Y] += (*nfp).nfp[cont].p[k-1][Y];
            }

            cont++;
        }
    }

    return;
}

int hexagon_nfp(char *filename, int *n, _item **items){

    int i, ii, j, jj, k, l, u, v, p, q;
    int maxX, maxY, minX, minY;
    _polygon pfix, porbital;
    _nofit nofit;
    _triangulation tfix, torbital;

    _item *itemlist;
    itemlist = *items;

    //item fixo
    for (i = 0; i < *n; i++) {
        itemlist[i].NFPs = (_nofit *****) calloc(itemlist[i].flip+1, sizeof(_nofit ****));

        //flip item fixo
        for (j = 0; j <= itemlist[i].flip; j++) {
            itemlist[i].NFPs[j] = (_nofit ****) calloc(itemlist[i].nr, sizeof(_nofit ***));

            //rotation item fixo
            for (k = 0; k < itemlist[i].nr; k++) {
                itemlist[i].NFPs[j][k] = (_nofit ***) calloc(*n, sizeof(_nofit **));

                //item orbital
                for (l = 0; l < *n; l++) {
                    itemlist[i].NFPs[j][k][l] = (_nofit **) calloc(itemlist[l].flip+1, sizeof(_nofit *));

                    //flip item orbital
                    for (u = 0; u <= itemlist[l].flip; u++) {
                        itemlist[i].NFPs[j][k][l][u] = (_nofit *) calloc(itemlist[l].nr, sizeof(_nofit));

                        //rotation item orbital
                        for (v = 0; v < itemlist[l].nr; v++) {
                            //itemlist[i].NFPs[j][k][l][u][v] = (_nofit *) calloc(1, sizeof(_nofit));
                            itemlist[i].NFPs[j][k][l][u][v].nfp[0].n = itemlist[i].np*itemlist[j].np;
                            for (p = 0; p < itemlist[i].np; p++) {
                               for (q = 0; q < itemlist[j].np; q++) {

                                    //item fix
                                    new_polygon(&itemlist[i].polygon[p], &pfix, itemlist[i].rotations[k], j);
                                    triangulate(&pfix, &tfix);

                                    //item orbital
                                    new_polygon(&itemlist[l].polygon[q], &porbital, itemlist[l].rotations[v], u);
                                    triangulate(&porbital, &torbital);

                                    nfp(&pfix, &tfix, &porbital, &torbital, &nofit);

                                    itemlist[i].NFPs[j][k][l][u][v].max[X] = -INF;
                                    itemlist[i].NFPs[j][k][l][u][v].max[Y] = -INF;
                                    itemlist[i].NFPs[j][k][l][u][v].min[X] = INF;
                                    itemlist[i].NFPs[j][k][l][u][v].min[Y] = INF;

                                    for (ii = 0; ii < nofit.n; ii++) {
                                        for (jj = 0; jj < 6; jj++) {
                                            itemlist[i].NFPs[j][k][l][u][v].nfp[ii].p[jj][X] = nofit.nfp[ii].p[jj][X];
                                            itemlist[i].NFPs[j][k][l][u][v].nfp[ii].p[jj][Y] = nofit.nfp[ii].p[jj][Y];

                                            if(itemlist[i].NFPs[j][k][l][u][v].max[X] < nofit.nfp[ii].p[jj][X])
                                                itemlist[i].NFPs[j][k][l][u][v].max[X] = nofit.nfp[ii].p[jj][X];
                                            if(itemlist[i].NFPs[j][k][l][u][v].max[Y] < nofit.nfp[ii].p[jj][Y])
                                                itemlist[i].NFPs[j][k][l][u][v].max[Y] = nofit.nfp[ii].p[jj][Y];
                                            if(itemlist[i].NFPs[j][k][l][u][v].min[X] > nofit.nfp[ii].p[jj][X])
                                                itemlist[i].NFPs[j][k][l][u][v].min[X] = nofit.nfp[ii].p[jj][X];
                                            if(itemlist[i].NFPs[j][k][l][u][v].min[Y] > nofit.nfp[ii].p[jj][Y])
                                                itemlist[i].NFPs[j][k][l][u][v].min[Y] = nofit.nfp[ii].p[jj][Y];

                                        }
                                    }

                                    maxX = floor(itemlist[i].NFPs[j][k][l][u][v].max[X]); 
                                    minX = floor(itemlist[i].NFPs[j][k][l][u][v].min[X]);
                                    maxY = floor(itemlist[i].NFPs[j][k][l][u][v].max[Y]); 
                                    minY = floor(itemlist[i].NFPs[j][k][l][u][v].min[Y]);

                                    hexagon_nfpOut(filename,nofit,i,j,itemlist[i].rotations[k],l,u,itemlist[l].rotations[v], maxX, maxY, minX, minY);

                                }
                            }
                        }
                    }
                }
            }
        }
    }
    return(0);
}


void hexagon_nfpOut(char *filename,_nofit nfp,int i,int j,double k,int l,int u,double v, int maxX, int maxY, int minX, int minY){

    int ii, jj, kk;
    bool flag;
    int cont;
    _point pnt;
    FILE *arq;
    char local[50];

    sprintf(local,"instances/%s/nfp_polygon/%d_%d_%.0f_%d_%d_%.0f.in", filename, i+1, j, k, l+1, u, v);

    // write mode with file creation -> w +
    arq = fopen(local, "w+"); 

    if (arq == NULL) {
        printf("\nError creating output file!\n");
        return;
    }

    // writes the information in the file
    fprintf(arq, "# number of polygons positive and negative\n%d 0\n", nfp.n);

    for (ii = 0; ii < nfp.n; ii++) {
        fprintf(arq, "# polygon %d:number vertices\n6\n# vertices\n", ii+1);
        for (jj = 0; jj < 6; jj++) {
            fprintf(arq,"%.2f %.2f\n",nfp.nfp[ii].p[jj][X] ,nfp.nfp[ii].p[jj][Y]);
        }
    }

    // closes the output file after recording the information
    fclose(arq);


    sprintf(local,"instances/%s/nfp_polygon/%d_%d_%.0f_%d_%d_%.0f.pfg", filename, i+1, j, k, l+1, u, v);

    // write mode with file creation -> w +
    arq = fopen(local, "w+"); 

    if (arq == NULL) {
        printf("\nError creating output file!\n");
        return;
    }

    // writes the information in the file
    fprintf(arq, "\\begin{tikzpicture}\n");

    for (ii = 0; ii < nfp.n; ii++) {
        fprintf(arq,"\\draw[thin,black!80] ");
        for (jj = 0; jj < 6; jj++) {
            fprintf(arq,"(%.0f,%.0f)--",nfp.nfp[ii].p[jj][X] ,nfp.nfp[ii].p[jj][Y]);
        }
        fprintf(arq,"cycle;\n");
    }

    fprintf(arq, "\\end{tikzpicture}");
    // closes the output file after recording the information
    fclose(arq);


    sprintf(local,"instances/%s/nfp_grid/%d_%d_%.0f_%d_%d_%.0f.in", filename, i+1, j, k, l+1, u, v);

    // write mode with file creation -> w +
    arq = fopen(local, "w+"); 

    if (arq == NULL) {
        printf("\nError creating output file!\n");
        return;
    }

    // writes the information in the file
    fprintf(arq, "# height and width\n");
    fprintf(arq, "%d %d\n", maxX-minX, maxY-minY);
    fprintf(arq, "# number of defects\n1\n");

    for (ii = minY; ii < maxY; ii++) {
        pnt[Y] = ii;
        for (jj = minX; jj < maxX; jj++) {
            pnt[X] = jj;
            flag = TRUE;
            cont = 0;
            for (kk = 0; kk < nfp.n; kk++) {
                flag = point_in_polygon_convex_grid(pnt, nfp.nfp[kk]);
                //printf("aqui, %d", flag);getchar();
                if(flag == FALSE) cont++;
            }
            if(cont == kk)
                fprintf(arq, "0 ");
            else
                fprintf(arq, "5 ");
        }
        fprintf(arq, "\n");
    }

    // closes the output file after recording the information
    fclose(arq);


    sprintf(local,"instances/%s/nfp_grid/%d_%d_%.0f_%d_%d_%.0f.pfg", filename, i+1, j, k, l+1, u, v);

    // write mode with file creation -> w +
    arq = fopen(local, "w+"); 

    if (arq == NULL) {
        printf("\nError creating output file!\n");
        return;
    }

    // writes the information in the file
    fprintf(arq, "\\begin{tikzpicture}\n");
    fprintf(arq, "\\matrix \n{");

    for (ii = minY; ii < maxY; ii++) {
        pnt[Y] = ii;
        for (jj = minX; jj < maxX; jj++) {
            pnt[X] = jj;
            flag = TRUE;
            cont = 0;
            for (kk = 0; kk < nfp.n; kk++) {
                flag = point_in_polygon_convex_grid(pnt, nfp.nfp[kk]);

                if(flag == FALSE) cont++;
            }
            if(cont == kk)
                fprintf(arq, " \\node { };&[-1mm] ");
            else
                fprintf(arq, " \\node {5};&[-1mm] ");
        }
        fprintf(arq, "\\\\\n");
    }
    fprintf(arq, "};\n\\end{tikzpicture}");

    // closes the output file after recording the information
    fclose(arq);

    return;
}

int grid_nfp(char *filename, int *n, _item **items){

   return(0); 
}

