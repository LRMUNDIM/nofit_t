//  data read from the general data of instance

#ifndef data_h
#define data_h

// data read from the general data of instance
// description: This function reads the number item types, the amount of rotation of each item and its rotations as well as their IDs.
int general_data(char *filename, int *n, _item **items);

// data read from the items data
// description: This function reads the items from the input files. The input parameter is the filename of instance and  the number of items (n) and the items (_item). And output parameters is a vector with the characteristics of each item (flip of item, number of solid polygons and hole polygons, and number of vertices of each polygon and the vertices).
int items_data(char *filename, int *n, _item **items);

#endif
