/// contains all geometric functions used in the algorithm

#ifndef nofit_h
#define nofit_h

// calculate the nofit polygon (nfp) of the polygon fix "pa" and o polygon orbital "pb". 
// This nofit is done ​​using the triangulation of the polygons "pa" and "pb".
void nfp(_polygon *pa, _triangulation *ta, _polygon *pb, _triangulation *tb, _nofit *nfp);

// calculate the nofit polygon of the instance
void calculate_nfp(char *filename, int *n, _item **items);

// draw the nofit polygons
void nfpDraw(_nofit nfp);

#endif

