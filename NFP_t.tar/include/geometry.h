/// contains all geometric functions used in the algorithm

#ifndef geometry_h
#define geometry_h

// returns the area of the triangle formed by the points (a, b, c)
// The area is negative if the triangle is in anti-clockwise. 
// If the triangle is clockwise the area is positive.
// If area is zero the points are collinear.
double signed_triangle_area(_point a, _point b, _point c);

// copies the point "a" to point "b"
void copy_point(_point a, _point b) ;

// returns if the points ( a, b, c) are clockwise or collinear (TRUE) if the points are counterclockwise return (FALSE)
bool cw(_point a, _point b, _point c);

// returns if the point p are inside of polygon clockwise (1) in bourd (0) or outside (-1)
int d_func(_point a, _point b, _point p);

// checks if the point (point) is inside the polygon (p)
bool point_in_polygon_convex(_point point, _polygon p);

// returns the segment formed by origen (0,0) and the point (p) with respect to the x-axis 
double angle(_point a);

#endif

