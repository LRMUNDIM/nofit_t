
// contains all macros used in the algorithm

#ifndef macros_h
#define macros_h

#define PI    3.14159265359 // ratio of circumference to diameter
#define ZERO    0.00000001  // a quantity small enough to be zero
#define INF    2E32         // a quantity small enough to be zero
#define DIMENSION    2      // dimension of points
#define X        0          // x-coordinate index
#define Y        1          // y-coordinate index
#define MAXPOLY     200     // maximum number of points in a polygon
#define MAXPART     200     // maximum number of parts in a nofit
#define TRUE    1
#define FALSE   0


//    Comparison macros

#define max(A, B)        ((A) > (B) ? (A) : (B))
#define min(A, B)        ((A) < (B) ? (A) : (B))

#define DEGREES_RADIANS(angle) (((angle) / 180.0) * PI)
#define rotationX(x1, y1, radians) ( ( x1 * cos(radians) ) - ( y1 * sin (radians) ) )
#define rotationY(x1, y1, radians) ( ( x1 * sin(radians) ) + ( y1 * cos (radians) ) )

#endif
