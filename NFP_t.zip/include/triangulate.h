/// contains all geometric functions used in the algorithm

#ifndef triangulate_h
#define triangulate_h

// returns the triangulation of the polygon (p) in (t)
void triangulate(_polygon *p, _triangulation *t);

// checks if the point (p) is inside the triangle (t)
bool point_in_triangle(_point p, triangle t);

// adds the triangle formed by the vertices (i,j,k) of the polygon (p) in triangulation (t)
void add_triangle(_triangulation *t, int i, int j, int k, _polygon *p);

// returns if the triangle formed by the vertices (i,j,k) of the polygon (p) is ear (TRUE) or not (FALSE)
bool ear_Q(int i, int j, int k, _polygon *p);

#endif

