
// contains all libraries used in the algorithm

#ifndef bibliotecas_h
#define bibliotecas_h

#include <stdio.h>
#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#include "macros.h"
#include "structs.h"
#include "data.h"
#include "geometry.h"
#include "nofit.h"
#include "triangulate.h"

#endif
