
// contains all struct used in the algorithm
#include "macros.h"
#ifndef structs_h
#define structs_h

typedef double _point[DIMENSION];

typedef struct {
    int n;                  // number of points in polygon
    _point p[MAXPOLY];      // array of points in polygon
} _polygon;

typedef _point triangle[3]; // triangle datatype

typedef struct {
    int n;                  // number of triangles in triangulation
    int t[MAXPOLY][3];      // indicies of vertices in triangulation
} _triangulation;

typedef struct {
    int n;                  // number of polygons in nofit polygon
    _polygon nfp[MAXPART];  // array of polygons in nofit polygon
    int **grid;
    _point max, min;
} _nofit;

typedef int bool;

typedef struct {
    int ID;                 // identification to the item
    bool flip;              // if the item no flip (FALSE) or if item is flip (TRUE)
    int nr;                 // number of rotations
    double *rotations;      // array with the rotations
    int np;                 // number of simple polygons 
    _polygon *polygon;      // array with the polygons
    _nofit *****NFPs;       // matrix NFP[i][j][k][l][m] where: item fix flip [i] and angle [j]; item orbital [k] with flip [l], angle [m]
} _item;


#endif
