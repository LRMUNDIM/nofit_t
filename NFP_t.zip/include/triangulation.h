/// contains all geometric functions used in the algorithm

#ifndef geometry_h
#define geometry_h

// returns the triangulation of the polygon (p) in (t)
void triangulate(_polygon *p, _triangulation *t);

// checks if the point (p) is inside the triangle (t)
bool point_in_triangle(_point p, triangle t);

// adds the triangle formed by the vertices (i,j,k) of the polygon (p) in triangulation (t)
void add_triangle(_triangulation *t, int i, int j, int k, _polygon *p);

// returns the area of the triangle formed by the points (a, b, c)
// The area is negative if the triangle is in anti-clockwise. 
// If the triangle is clockwise the area is positive.
// If area is zero the points are collinear.
double signed_triangle_area(_point a, _point b, _point c);

// copies the point a to point b
void copy_point(_point a, _point b) ;

// returns if the points ( a, b, c) are clockwise or collinear (TRUE) if the points are counterclockwise return (FALSE)
bool cw(_point a, _point b, _point c);

// returns if the triangle formed by the vertices (i,j,k) of the polygon (p) is ear (TRUE) or not (FALSE)
bool ear_Q(int i, int j, int k, _polygon *p);

// invert the orientation of the polygon (p)
void invert_orientation(_polygon *p);

// returns the segment formed by origen (0,0) and the point (p) with respect to the x-axis 
double angle(_point a);

#endif

