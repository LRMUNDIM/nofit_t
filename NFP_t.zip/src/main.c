#include "bibliotecas.h"

int main(int argc,char *argv[]){

    int n;                    // number of items
    _item *items;             // vector to allocate all items
    char *instance;           // name of the instance used
    int flag;                 

    //checked instance
    if (argc == 2) instance = argv [1];
    else {
        printf("\n\nError: <instance> .\n\n");
        return(-1);
    }

    flag = general_data(instance, &n, &items);
    if (flag == 0) printf("General data: ok\n");
    else { 
        printf("Erro no general data!\n");
        return(-1);
    }

    flag = items_data(instance, &n, &items);
    if (flag == 0) printf("Items data: ok\n");
    else { 
        printf("Erro no items data!\n");
        return(-1);
    }

    flag = hexagon_nfp(instance, &n, &items);
    if (flag == 0) printf("Nofit polygon: ok\n");
    else { 
        printf("Erro no calculate nfp!\n");
        return(-1);
    }

    printf("Executado com sucesso!\n");
    return(0);
}
