#include "bibliotecas.h"

double signed_triangle_area(_point a, _point b, _point c){
    return( (a[X]*b[Y] - a[Y]*b[X] + a[Y]*c[X] 
        - a[X]*c[Y] + b[X]*c[Y] - c[X]*b[Y]) / 2.0 );
}


void copy_point(_point a, _point b) {
    int i;              

    for (i=0; i<DIMENSION; i++) b[i] = a[i];
}

bool cw(_point a, _point b, _point c){
    return (signed_triangle_area(a,b,c) < - ZERO);
}

int d_func(_point a, _point b, _point p){
	double d = (a[X]-b[X])*(a[Y]-p[Y])-(a[Y]-b[Y])*(a[X]-p[X]);
	if (fabs(d) < ZERO)
		return (0);
	else if (d < 0)
		return (-1);
	else
		return (1);
}


bool point_in_polygon_convex(_point point, _polygon p){
    int i;                  

    for (i=0; i<p.n; i++){
        if (d_func(p.p[i],p.p[(i+1)%p.n],point)<=0){
            return(FALSE);
        }
    }
    return(TRUE);
}


double angle(_point a) {

    //x-axis
    if (fabs(a[Y]) < ZERO){
        if(a[X] > 0){
            return(0);
        }
        else{
            return(180);
        }
    }

    //y-axis
    if (fabs(a[X]) < ZERO){
        if(a[Y] > 0){
            return(90);
        }
        else{
            return(270);
        }
    }

    if (a[X] > 0){

        if (a[Y] > 0){
            //first quadrant
            return(atan (a[Y]/a[X]) * 180 / PI);
        }
        else{
            //quart quadrant
            return( 360 + atan (a[Y]/a[X]) * 180 / PI);
        }
    }
    else{
        if (a[Y] > 0){
            //second quadrant
            return( 180 + atan (a[Y]/a[X]) * 180 / PI);
        }
        else{
            //third quadrant
            return(180 + atan (a[Y]/a[X]) * 180 / PI);
        }
    }
}
